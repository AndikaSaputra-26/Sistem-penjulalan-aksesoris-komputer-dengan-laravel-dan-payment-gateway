<?php $__env->startSection('title', 'Toko Online'); ?>
<?php $__env->startSection('content'); ?>

    <div class="breadcrumb">
        <div class="container">
            <div class="breadcrumb-inner">
                <ul class="list-inline list-unstyled">
                    <li><a href="#">Home</a></li>
                    <li class='active'>Sale</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="body-content outer-top-xs">
        <div class='container'>
            <div class='row'>
                
                <?php echo $__env->make('frontend._include-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class='col-md-9'>
                    <div id="category" class="category-carousel hidden-xs">
                        <div class="item">
                            <div class="image">
                                <img src=" <?php echo e(asset('temp-front-end/assets/images/banners/banner.jpg')); ?>" alt=""
                                    class="img-responsive">
                            </div>
                        </div>
                    </div>
                    <div class="search-result-container ">
                        <div id="myTabContent" class="tab-content category-list">
                            <div class="tab-pane active " id="grid-container">
                                <div class="category-product">
                                    <div class="row">

                                        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <form action="<?php echo e(route('cart.store')); ?>" method="POST"
                                                enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>

                                                <div class="col-sm-6 col-md-4 wow fadeInUp">
                                                    <div class="products">
                                                        <div class="product">
                                                            <div class="product-image">
                                                                <div class="image">
                                                                    <a
                                                                        href="<?php echo e(route('detail-produk', ['id' => $row->id, 'slug' => $row->slug])); ?>">
                                                                        <?php
                                                                            $thumbnail = DB::table('produk_photo')
                                                                                ->where('produk_id', $row->id)
                                                                                ->first();
                                                                        ?>
                                                                        <img style="height: 250px"
                                                                            src="<?php echo e(Storage::url('public/produk/' . $thumbnail->photo)); ?>"
                                                                            alt=""></a>
                                                                </div>
                                                                <div class="tag new"><span>new</span></div>
                                                            </div>
                                                            <div class="product-info text-left">
                                                                <h3 class="name"><a
                                                                        href="<?php echo e(route('detail-produk', ['id' => $row->id, 'slug' => $row->slug])); ?>"><?php echo e($row->kode_produk); ?>

                                                                        - <?php echo e($row->nama); ?></a>
                                                                </h3>
                                                                <div class="description"></div>
                                                                <div class="product-price">
                                                                    <span class="price">
                                                                        Rp. <?php echo number_format($row->harga,0,',','.'); ?></span>
                                                                </div>
                                                            </div>
                                                            <div class="cart clearfix animate-effect">
                                                                <div class="action">
                                                                    <ul class="list-unstyled">
                                                                        <li class="add-cart-button btn-group">
                                                                            <input type="hidden" value="1" name="quantity">

                                                                            <input type="hidden" value="<?php echo e($row->id); ?>"
                                                                                name="id">
                                                                            <input type="hidden" value="<?php echo e($row->nama); ?>"
                                                                                name="nama">
                                                                            <input type="hidden"
                                                                                value="<?php echo e($row->harga); ?>" name="harga">
                                                                            <input type="hidden"
                                                                                value="<?php echo e($thumbnail->photo); ?>"
                                                                                name="photo">
                                                                            <button class="btn btn-primary icon"><i
                                                                                    class="fa fa-shopping-cart"></i>
                                                                            </button>

                                                                        </li>
                                                                        <li class="lnk wishlist">
                                                                            <a class="add-to-cart"
                                                                                href="<?php echo e(route('wishlist-store',$row->id)); ?>"
                                                                                title="Wishlist">
                                                                                <i class="icon fa fa-heart"></i>
                                                                            </a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix filters-container">

                            <div class="text-right">
                                <div class="pagination-container">
                                    <?php if($produk->hasPages()): ?>
                                        <?php if($produk->lastPage() > 1): ?>
                                            <ul class="list-inline list-unstyled">
                                                <li class="prev">
                                                    <a href="<?php echo e($produk->url(1)); ?>"><i class="fa fa-angle-left"></i></a>
                                                </li>
                                                <?php for($i = 1; $i <= $produk->lastPage(); $i++): ?>
                                                    <li class="<?php echo e($produk->currentPage() == $i ? ' active' : ''); ?>">
                                                        <a href="<?php echo e($produk->url($i)); ?>"><?php echo e($i); ?></a>
                                                    </li>
                                                <?php endfor; ?>
                                                <li class="next">
                                                    <a href="<?php echo e($produk->url($produk->currentPage() + 1)); ?>">
                                                        <i class="fa fa-angle-right"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1801231/public_html/ip-komputer.com/resources/views/frontend/index.blade.php ENDPATH**/ ?>