<link rel="stylesheet" href=" <?php echo e(asset('temp-front-end/assets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('temp-front-end/assets/css/main.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('temp-front-end/assets/css/blue.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('temp-front-end/assets/css/owl.carousel.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('temp-front-end/assets/css/owl.transitions.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('temp-front-end/assets/css/animate.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('temp-front-end/assets/css/rateit.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('temp-front-end/assets/css/bootstrap-select.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('temp-front-end/assets/css/font-awesome.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('temp-front-end/assets/css/lightbox.css')); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css"
    integrity="sha512-aOG0c6nPNzGk+5zjwyJaoRUgCdOrfSDhmMID2u4+OIslr0GjpLKo7Xm0Ao3xmpM4T8AmIouRkqwj1nrdVsLKEQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,600italic,700,700italic,800'
    rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<?php /**PATH /home/u1801231/public_html/ip-komputer.com/resources/views/layouts/_frontEnd/style.blade.php ENDPATH**/ ?>