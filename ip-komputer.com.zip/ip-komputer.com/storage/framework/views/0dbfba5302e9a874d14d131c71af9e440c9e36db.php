<?php $__env->startSection('title', 'Data Customer'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php echo e(Breadcrumbs::render('customer_index')); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card shadow mb-4">
                    <div class="card-body">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer_create')): ?>
                            <a href="<?php echo e(route('customer.create')); ?>" class="btn btn-md btn-success mb-3">TAMBAH</a>
                        <?php endif; ?>

                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nama Customer</th>
                                        <th>Tanggal Lahir</th>
                                        <th>Jenis Kelamin</th>
                                        <th>Email</th>
                                        <th>No Telpon</th>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['customer_update', 'customer_delete'])): ?>
                                            <th>Action</th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        const action =
            '<?php echo e(auth()->user()->can('supplier_update') ||auth()->user()->can('supplier_delete')? 'yes yes yes': ''); ?>'
        let columns = [
            {
                data: 'DT_RowIndex',
                name: 'DT_RowIndex',
                orderable: false,
                searchable: false
            },
            {
                data: 'nama',
                name: 'nama'
            },
            {
                data: 'tanggal_lahir',
                name: 'tanggal_lahir'
            },
            {
                data: 'jenis_kelamin',
                name: 'jenis_kelamin'
            },
            {
                data: 'email',
                name: 'email'
            },
            {
                data: 'telpon',
                name: 'telpon'
            },

        ]

        if (action) {
            columns.push({
                data: 'action',
                name: 'action',
                orderable: false,
                searchable: false
            })
        }

        $('#dataTable').DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('customer.index')); ?>",
            columns: columns
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1801231/public_html/ip-komputer.com/resources/views/customer/index.blade.php ENDPATH**/ ?>