<td>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('address_show')): ?>
    <a href="<?php echo e(route('address', $model->id)); ?>" class="btn btn-success btn-xs mb-1" title="Data Alamat">
        <i class="fas fa-address-book"></i>
    </a>
<?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer_update')): ?>
        <a href="<?php echo e(route('customer.edit', $model->id)); ?>" class="btn btn-primary btn-xs mb-1">
            <i class="fas fa-edit"></i>
        </a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer_delete')): ?>
        <form action="<?php echo e(route('customer.destroy', $model->id)); ?>" method="post" class="d-inline"
            onsubmit="return confirm('Yakin ingin menghapus data ini?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button class="btn btn-danger btn-xs mb-1">
                <i class="fas fa-trash-alt"></i>
            </button>
        </form>
    <?php endif; ?>
</td>
<?php /**PATH /home/u1801231/public_html/ip-komputer.com/resources/views/customer/_action.blade.php ENDPATH**/ ?>