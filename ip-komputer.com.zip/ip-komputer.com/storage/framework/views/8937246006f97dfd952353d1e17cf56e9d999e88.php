<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; <?php echo e(date('Y')); ?></span>
        </div>
    </div>
</footer>
<?php /**PATH /home/u1801231/public_html/ip-komputer.com/resources/views/layouts/_dashboard/footer.blade.php ENDPATH**/ ?>