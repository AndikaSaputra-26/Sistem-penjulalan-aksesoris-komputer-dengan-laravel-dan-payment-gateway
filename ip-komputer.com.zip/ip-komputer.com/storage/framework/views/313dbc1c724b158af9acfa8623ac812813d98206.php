<!DOCTYPE html>
<html lang="en">

<head>
    
    <?php echo $__env->make('layouts._auth.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('layouts._auth.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="bg-gradient-primary">
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-xl-6 col-lg-6 col-md-6">
                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Selamat Datang Kembali!</h1>
                            </div>
                            
                            <?php echo $__env->yieldContent('content'); ?>
                        </div>
                    </div>
                </div>

            </div>

        </div>
        <?php echo $__env->make('layouts._auth.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /home/u1801231/public_html/ip-komputer.com/resources/views/layouts/auth.blade.php ENDPATH**/ ?>