<div class='col-md-3 sidebar'>
    <div class="side-menu animate-dropdown outer-bottom-xs">
        <div class="head"><i class="icon fa fa-align-justify fa-fw"></i> Categories</div>
        <nav class="yamm megamenu-horizontal" role="navigation">
            <ul class="nav">
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="">
                        <a href="<?php echo e(route('kategori-produk',['id' => $data->id,'name' =>$data->nama_kategori ])); ?>"><?php echo e($data->nama_kategori); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </nav>
    </div>
</div>
<?php /**PATH /home/u1801231/public_html/ip-komputer.com/resources/views/frontend/_include-sidebar.blade.php ENDPATH**/ ?>