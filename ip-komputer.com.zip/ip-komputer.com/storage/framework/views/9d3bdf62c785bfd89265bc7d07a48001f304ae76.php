<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Meta -->
    <?php echo $__env->make('layouts._frontEnd.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Toko Online</title>
    
    <?php echo $__env->make('layouts._frontEnd.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('css'); ?>

</head>

<body>
    
    <?php echo $__env->make('layouts._frontEnd.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    
    <?php echo $__env->make('layouts._frontEnd.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('layouts._frontEnd.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('js'); ?>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /home/u1801231/public_html/ip-komputer.com/resources/views/layouts/master-frontend.blade.php ENDPATH**/ ?>