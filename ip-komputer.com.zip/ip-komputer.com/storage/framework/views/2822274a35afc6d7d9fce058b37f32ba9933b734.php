<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('content'); ?>
    <!-- ============================================== HEADER : END ============================================== -->
    <div class="breadcrumb">
        <div class="container">
            <div class="breadcrumb-inner">
                <ul class="list-inline list-unstyled">
                    <li><a href="home.html">Home</a></li>
                    <li class='active'>Login</li>
                </ul>
            </div><!-- /.breadcrumb-inner -->
        </div><!-- /.container -->
    </div><!-- /.breadcrumb -->

    <div class="body-content">
        <div class="container">
            <div class="sign-in-page">
                <div class="row">
                    <!-- Sign-in -->
                    <div class="col-md-6">
                        <center>
                            <img src="<?php echo e(asset('temp-front-end/assets/images/login.webp')); ?>" alt="" width="80%">
                        </center>
                    </div>
                    <div class="col-md-6 col-sm-6 sign-in">
                        <h4 class="checkout-subtitle">
                            <div class="alert alert-info">
                                <i class="fa fa-info-circle" aria-hidden="true"></i> Login User
                            </div>
                        </h4>
                        <form class="register-form outer-top-xs" method="post" action="<?php echo e(route('auth-user')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label class="info-title" for="email">Email<span>*</span></label>
                                <input type="email" name="email" value="<?php echo e(old('email')); ?>"
                                    class="form-control unicase-form-control text-input" id="email">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: red;"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label class="info-title" for="password">Password <span>*</span></label>
                                <input type="password" class="form-control unicase-form-control text-input" name="password"
                                    id="password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: red;"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <p style="float: right"><a href="" data-toggle="modal" data-target="#tesModal">Forgot Password
                                    ?</a></p>
                            <button type="submit" class="btn-upper btn btn-primary checkout-page-button">Login</button>
                        </form>
                    </div>

                    <!-- Sign-in -->
                </div><!-- /.sigin-in-->
            </div><!-- /.container -->
        </div><!-- /.body-content -->
    <?php $__env->stopSection(); ?>

    
    <div class="modal fade" id="tesModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button class="close" data-dismiss="modal"><span>&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Reset Password</h4>
                </div>
                <div class="modal-body">
                    <form method="POST" action="<?php echo e(route('sendReset')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="">Masukan Email Terdaftar</label>
                            <input required type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" id="alamat_lengkap"
                                placeholder="Masukan Email Terdaftar">
                        </div>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">SEND PASSWORD RESET LINK</button>
                </div>
            </form>
            </div>
        </div>
    </div>

<?php echo $__env->make('layouts.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1801231/public_html/ip-komputer.com/resources/views/frontend/login.blade.php ENDPATH**/ ?>