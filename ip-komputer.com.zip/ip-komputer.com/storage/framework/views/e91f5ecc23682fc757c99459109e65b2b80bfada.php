<?php $__env->startSection('title', 'Detail Produk'); ?>
<?php $__env->startSection('content'); ?>
    <div class="breadcrumb">
        <div class="container">
            <div class="breadcrumb-inner">
                <ul class="list-inline list-unstyled">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Produk</a></li>
                    <li class='active'>Detail Produk - <?php echo e($data->nama); ?></li>
                </ul>
            </div><!-- /.breadcrumb-inner -->
        </div>
    </div><!-- /.breadcrumb -->
    <div class="body-content outer-top-xs">
        <div class='container'>
            <div class='row single-product'>
                <div class='col-md-12'>
                    <div class="detail-block">
                        <div class="row  wow fadeInUp">

                            <div class="col-xs-12 col-sm-6 col-md-5 gallery-holder">
                                <div class="product-item-holder size-big single-product-gallery small-gallery">

                                    <div id="owl-single-product">

                                        <?php
                                            $photo = DB::table('produk_photo')
                                                ->where('produk_id', '=', $data->id)
                                                ->get();
                                        ?>

                                        <?php $__currentLoopData = $photo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="single-product-gallery-item" id="slide<?php echo e($rows->id); ?>">
                                                <a data-lightbox="image-1" data-title="Gallery"
                                                    href="<?php echo e(Storage::url('public/produk/' . $rows->photo)); ?>">
                                                    <img class="" alt="" width="400" height="450"
                                                        src="<?php echo e(asset('temp-front-end/assets/images/blank.gif')); ?> "
                                                        data-echo="<?php echo e(Storage::url('public/produk/' . $rows->photo)); ?>" />
                                                </a>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>



                                    <div class="single-product-gallery-thumbs gallery-thumbs">
                                        <div id="owl-single-product-thumbnails">
                                            <?php $__currentLoopData = $photo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="item">
                                                    <a class="horizontal-thumb <?php if($loop->iteration == 1): ?> active <?php endif; ?>"
                                                        data-target="#owl-single-product"
                                                        data-slide="<?php echo e($loop->iteration - 1); ?>"
                                                        href="#slide<?php echo e($rows->id); ?>">
                                                        <img style="display: block" width="85" height="100" alt=""
                                                            src="<?php echo e(asset('temp-front-end/assets/images/blank.gif')); ?> "
                                                            data-echo="<?php echo e(Storage::url('public/produk/' . $rows->photo)); ?>" />
                                                    </a>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div><!-- /#owl-single-product-thumbnails -->



                                    </div><!-- /.gallery-thumbs -->

                                </div><!-- /.single-product-gallery -->
                            </div><!-- /.gallery-holder -->
                            <div class='col-sm-6 col-md-7 product-info-block'>
                                <div class="product-info">
                                    <h1 class="name"><?php echo e($data->kode_produk); ?> - <?php echo e($data->nama); ?></h1>
                                    <div class="stock-container info-container m-t-10">
                                        <div class="row">
                                            <div class="col-sm-2">
                                                <div class="stock-box">
                                                    <span class="label">Availability :</span>
                                                </div>
                                            </div>
                                            <div class="col-sm-9">
                                                <div class="stock-box">
                                                    <?php if($data->qty > 0): ?>
                                                        <span class="value">In Stock</span>
                                                    <?php else: ?>
                                                    <span class="value">Out of Stock</span>
                                                    <?php endif; ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="stock-container info-container m-t-10">
                                        <div class="row">
                                            <div class="col-sm-2">
                                                <div class="stock-box">
                                                    <span class="label">Kategori :</span>
                                                </div>
                                            </div>
                                            <div class="col-sm-9">
                                                <div class="stock-box">
                                                    <span
                                                        class="value"><?php echo e($data->kategori->nama_kategori); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="stock-container info-container m-t-10">
                                        <div class="row">
                                            <div class="col-sm-2">
                                                <div class="stock-box">
                                                    <span class="label">Stok :</span>
                                                </div>
                                            </div>
                                            <div class="col-sm-9">
                                                <div class="stock-box">
                                                    <span class="value"><?php echo e($data->qty); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="stock-container info-container m-t-10">
                                        <div class="row">
                                            <div class="col-sm-2">
                                                <div class="stock-box">
                                                    <span class="label">Unit :</span>
                                                </div>
                                            </div>
                                            <div class="col-sm-9">
                                                <div class="stock-box">
                                                    <span class="value"><?php echo e($data->unit->nama_unit); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="description-container m-t-20" style="text-align: justify">
                                        <?php echo e($data->deskripsi); ?>

                                    </div>

                                    <div class="price-container info-container m-t-20">
                                        <div class="row">


                                            <div class="col-sm-6">
                                                <div class="price-box">
                                                    <span class="price">Rp. <?php echo number_format($data->harga,0,',','.'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <div class="favorite-button m-t-10">
                                                    <a class="btn btn-primary" data-toggle="tooltip" data-placement="right"
                                                        title="Wishlist" href="<?php echo e(route('wishlist-store', $data->id)); ?>">
                                                        <i class="fa fa-heart"></i>
                                                    </a>

                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <div class="quantity-container info-container">
                                        <div class="row">

                                            <div class="col-sm-2">
                                                <span class="label">Qty :</span>
                                            </div>
                                            <form action="<?php echo e(route('cart.store')); ?>" method="POST"
                                                enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="col-sm-2">
                                                    <div class="cart-quantity">
                                                        <div class="quant-input">
                                                            <div class="arrows">
                                                                <div class="arrow plus gradient"><span
                                                                        class="ir"><i
                                                                            class="icon fa fa-sort-asc"></i></span></div>
                                                                <div class="arrow minus gradient"><span
                                                                        class="ir"><i
                                                                            class="icon fa fa-sort-desc"></i></span></div>
                                                            </div>
                                                            <input type="text" value="1" name="quantity">
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-sm-7">
                                                    <input type="hidden" value="<?php echo e($data->id); ?>" name="id">
                                                    <input type="hidden" value="<?php echo e($data->nama); ?>" name="nama">
                                                    <input type="hidden" value="<?php echo e($data->harga); ?>" name="harga">
                                                    <?php
                                                        $thumbnail = DB::table('produk_photo')
                                                            ->where('produk_id', $data->id)
                                                            ->first();
                                                    ?>

                                                    <input type="hidden" value="<?php echo e($thumbnail->photo); ?>" name="photo">
                                                    <button class="btn btn-primary"><i
                                                            class="fa fa-shopping-cart inner-right-vs"></i> ADD TO
                                                        CART </button>
                                                </div>
                                            </form>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <section class="section featured-product wow fadeInUp">
                        <h3 class="section-title">Produk Terkait</h3>
                        <div class="owl-carousel home-owl-carousel upsell-product custom-carousel owl-theme outer-top-xs">
                            <?php $__currentLoopData = $relate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="item item-carousel">
                                        <div class="products">
                                            <div class="product">
                                                <div class="product-image">
                                                    <div class="image">
                                                        <a
                                                            href="<?php echo e(route('detail-produk', ['id' => $row->id, 'slug' => $row->slug])); ?>">
                                                            <?php
                                                                $thumbnail = DB::table('produk_photo')
                                                                    ->where('produk_id', $row->id)
                                                                    ->first();
                                                            ?>
                                                            <img style="height: 250px"
                                                                src="<?php echo e(Storage::url('public/produk/' . $thumbnail->photo)); ?>"
                                                                alt=""></a>
                                                    </div>

                                                    <div class="tag new"><span>new</span></div>
                                                </div>
                                                <div class="product-info text-left">
                                                    <h3 class="name"><a
                                                            href="<?php echo e(route('detail-produk', ['id' => $row->id, 'slug' => $row->slug])); ?>"><?php echo e($row->kode_produk); ?>

                                                            - <?php echo e($row->nama); ?></a>
                                                    </h3>
                                                    <div class="description"></div>

                                                    <div class="product-price">
                                                        <span class="price">
                                                            Rp. <?php echo number_format($row->harga,0,',','.'); ?></span>
                                                    </div>

                                                </div>
                                                <div class="cart clearfix animate-effect">
                                                    <div class="action">
                                                        <ul class="list-unstyled">
                                                            <li class="add-cart-button btn-group">
                                                                <input type="hidden" value="1" name="quantity">

                                                                <input type="hidden" value="<?php echo e($row->id); ?>" name="id">
                                                                <input type="hidden" value="<?php echo e($row->nama); ?>"
                                                                    name="nama">
                                                                <input type="hidden" value="<?php echo e($row->harga); ?>"
                                                                    name="harga">
                                                                <input type="hidden" value="<?php echo e($thumbnail->photo); ?>"
                                                                    name="photo">
                                                                <button class="btn btn-primary icon"><i
                                                                        class="fa fa-shopping-cart"></i>
                                                                </button>

                                                            </li>
                                                            <li class="lnk wishlist">
                                                                <a class="add-to-cart"
                                                                    href="<?php echo e(route('wishlist-store', $row->id)); ?>"
                                                                    title="Wishlist">
                                                                    <i class="icon fa fa-heart"></i>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </section>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1801231/public_html/ip-komputer.com/resources/views/frontend/detail-produk.blade.php ENDPATH**/ ?>