<header class="header-style-1">
    <div class="top-bar animate-dropdown">
        <div class="container">
            <div class="header-top-inner">

                <div class="cnt-account">
                    <ul class="list-unstyled">
                        <?php if(Session::get('login-customer')): ?>
                            <li><a href="<?php echo e(route('signout-user')); ?>"><i class="fa fa-sign-out" aria-hidden="true"></i>
                                    Logout</a></li>
                        <?php else: ?>
                            <li><a href="<?php echo e(route('auth-web')); ?>"><i class="fa fa-sign-in" aria-hidden="true"></i>
                                    Login</a></li>
                            <li><a href="<?php echo e(route('signin-web')); ?>"><i class="fa fa-wpforms" aria-hidden="true"></i>
                                    Register</a></li>
                        <?php endif; ?>

                    </ul>
                </div>

                <?php if(Session::get('login-customer')): ?>
                    <div class="cnt-block">
                        <ul class="list-unstyled list-inline">
                            <li class="dropdown dropdown-small">
                                <a href="#" class="dropdown-toggle" data-hover="dropdown" data-toggle="dropdown"><span
                                        class="value"><?php echo e(Session::get('name-customer')); ?> </span><b
                                        class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li><a href="<?php echo e(route('setting-akun')); ?>">Akun Profile</a></li>
                                    <li><a href="<?php echo e(route('pembelian')); ?>">Pembelian</a></li>
                                    <li><a href="<?php echo e(route('wishlist.index')); ?>">Wishlist</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
    <div class="main-header">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-3 logo-holder">
                    <div class="logo">
                        <a href="<?php echo e(route('dashboard')); ?>">
                            <img src="<?php echo e(asset('temp-front-end/assets/images/logo.png')); ?>" alt=""
                                style="width: 90%;">
                        </a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-7 top-search-holder">
                    <div class="search-area">
                        <form action="<?php echo e(route('pencarian-produk')); ?>" method="GET">
                            <div class="control-group">
                                <input required class="search-field typeahead" name="search" id="search"
                                    autocomplete="off" placeholder="Cari Produk" <?php if (isset($_GET['search'])) { ?>
                                    value="<?= $_GET['search'] ?>" <?php } ?> />
                                <button type="submit" class="search-button">
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <?php if(Session::get('login-customer')): ?>
                    <div class="col-xs-12 col-sm-12 col-md-2 animate-dropdown top-cart-row">
                        <div class="dropdown dropdown-cart">
                            <a href="#" class="dropdown-toggle lnk-cart" data-toggle="dropdown">
                                <div class="items-cart-inner">
                                    <div class="basket">
                                        <i class="glyphicon glyphicon-shopping-cart"></i>
                                    </div>
                                    <?php
                                        $cartItems = \Cart::getContent();
                                    ?>
                                    <div class="basket-item-count"><span
                                            class="count"><?php echo e(Cart::getTotalQuantity()); ?></span></div>
                                    <div class="total-price-basket">
                                        <span class="total-price">
                                            <span class="value"> Rp. <?php echo number_format(Cart::getTotal(),0,',','.'); ?></span>
                                        </span>
                                    </div>


                                </div>
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <div class="cart-item product-summary">

                                        
                                        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="row">
                                                <div class="col-xs-4">
                                                    <div class="image">
                                                        <?php
                                                            $thumbnail = DB::table('produk_photo')
                                                                ->where('produk_id', $item->id)
                                                                ->first();
                                                            $slug = DB::table('produk')
                                                                ->where('id', $item->id)
                                                                ->first();
                                                        ?>
                                                        <a
                                                            href="<?php echo e(route('detail-produk', ['id' => $item->id, 'slug' => $slug->slug])); ?>"><img
                                                                src="<?php echo e(Storage::url('public/produk/' . $thumbnail->photo)); ?>"
                                                                alt=""></a>
                                                    </div>
                                                </div>
                                                <div class="col-xs-7">

                                                    <h3 class="name"><a
                                                            href="<?php echo e(route('detail-produk', ['id' => $item->id, 'slug' => $slug->slug])); ?>"><?php echo e($item->name); ?>

                                                            -
                                                            <?php echo e($item->quantity); ?></a></h3>
                                                    <div class="price">Rp. <?php echo number_format($item->price,0,',','.'); ?></div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="clearfix"></div>
                                    <hr>
                                    <div class="clearfix cart-total">
                                        <div class="pull-right">
                                            <span class="text">Sub Total :</span><span
                                                class='price'>Rp. <?php echo number_format(Cart::getTotal(),0,',','.'); ?></span>
                                        </div>
                                        <div class="clearfix"></div>
                                        <a href="<?php echo e(route('cart.list')); ?>"
                                            class="btn btn-upper btn-primary btn-block m-t-20">Checkout</a>
                                        <form action="<?php echo e(route('cart.clear')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-upper btn-danger btn-block m-t-10">Hapus Semua
                                                Cart</button>
                                        </form>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>


            </div>

        </div>
        <div class="header-nav animate-dropdown">
            <div class="container">
                <div class="yamm navbar navbar-default" role="navigation">
                    <div class="navbar-header">
                        <button data-target="#mc-horizontal-menu-collapse" data-toggle="collapse"
                            class="navbar-toggle collapsed" type="button">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                    <div class="nav-bg-class">
                        <div class="navbar-collapse collapse" id="mc-horizontal-menu-collapse">
                            <div class="nav-outer">
                                <ul class="nav navbar-nav">
                                    <li class="dropdown hidden-sm">
                                        <a href="<?php echo e(route('dashboard')); ?>"><span
                                                class="menu-label hot-menu hidden-xs">hot</span>SALE</a>
                                    </li>

                                    <li class="dropdown">
                                        <a href="<?php echo e(route('tentang-kami')); ?>">TENTANG KAMI</a>
                                    </li>

                                    <li class="dropdown">
                                        <a href="<?php echo e(route('cara-belanja')); ?>">CARA BELANJA</a>
                                    </li>
                                    <li class="dropdown">
                                        <a href="<?php echo e(route('kontak')); ?>">KONTAK</a>
                                    </li>



                                </ul><!-- /.navbar-nav -->
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</header>
<?php /**PATH /home/u1801231/public_html/ip-komputer.com/resources/views/layouts/_frontEnd/header.blade.php ENDPATH**/ ?>