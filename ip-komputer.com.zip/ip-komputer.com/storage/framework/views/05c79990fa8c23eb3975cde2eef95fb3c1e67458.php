<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('home')); ?>">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-desktop"></i>
        </div>
        <div class="sidebar-brand-text mx-3"><?php echo e(config('app.name')); ?></div>
    </a>
    <hr class="sidebar-divider my-0">
    <li class="nav-item <?php echo e(set_active('home')); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
            <i class="fas fa-fw fa-home"></i>
            <span>Home</span></a>
    </li>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['unit_show', 'produk_show', 'kategori_show'])): ?>
        <li class="nav-item <?php echo e(set_active(['unit*', 'kategori*', 'produk*'])); ?>">
            <a class="nav-link <?php echo e(request()->routeIs('unit*', 'kategori*', 'produk*') ? '' : 'collapsed'); ?>" href="#"
                data-toggle="collapse" data-target="#collapseMasterProduk" aria-expanded="true"
                aria-controls="collapseMasterProduk">
                <i class="fas fa-fw fa-cube"></i>
                <span>Data Produk</span>
            </a>
            <div id="collapseMasterProduk"
                class="collapse <?php echo e(request()->routeIs('unit*', 'kategori*', 'produk*') ? 'show' : ''); ?>"
                aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('produk_show')): ?>
                        <a class="collapse-item <?php echo e(set_active(['produk*'])); ?>" href="<?php echo e(route('produk.index')); ?>">
                            Produk</a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kategori_show')): ?>
                        <a class="collapse-item <?php echo e(set_active(['kategori*'])); ?>" href="<?php echo e(route('kategori.index')); ?>">
                            Kategori Produk</a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('unit_show')): ?>
                        <a class="collapse-item <?php echo e(set_active(['unit*'])); ?>" href="<?php echo e(route('unit.index')); ?>"> Unit</a>
                    <?php endif; ?>

                </div>
            </div>
        </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['customer_show', 'supplier_show'])): ?>
        <li class="nav-item <?php echo e(set_active(['customer*', 'supplier*'])); ?>">
            <a class="nav-link <?php echo e(request()->routeIs('customer*', 'supplier*') ? '' : 'collapsed'); ?>" href="#"
                data-toggle="collapse" data-target="#collapseMasterKontak" aria-expanded="true"
                aria-controls="collapseMasterKontak">
                <i class="fas fa-address-card"></i>
                <span>Kontak</span>
            </a>
            <div id="collapseMasterKontak"
                class="collapse <?php echo e(request()->routeIs('customer*', 'supplier*') ? 'show' : ''); ?>"
                aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer_show')): ?>
                        <a class="collapse-item <?php echo e(set_active(['customer*'])); ?>" href="<?php echo e(route('customer.index')); ?>">
                            Customer</a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier_show')): ?>
                        <a class="collapse-item <?php echo e(set_active(['supplier*'])); ?>" href="<?php echo e(route('supplier.index')); ?>">
                            Supplier</a>
                    <?php endif; ?>
                </div>
            </div>
        </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['pembelian_show'])): ?>
        <li class="nav-item <?php echo e(set_active('pembelian*')); ?>">
            <a class="nav-link" href="<?php echo e(route('pembelian.index')); ?>">
                <i class="fas fa-fw fa-money-bill"></i>
                <span>Pembelian</span></a>
        </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['transaksi_show'])): ?>
        <li class="nav-item <?php echo e(set_active('transaksi*')); ?>">
            <a class="nav-link" href="<?php echo e(route('transaksi.index')); ?>">
                <i class="fas fa-shopping-cart"></i>
                <span>Penjualan</span></a>
        </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['pesan_show'])): ?>
        <li class="nav-item <?php echo e(set_active('pesan*')); ?>">
            <a class="nav-link" href="<?php echo e(route('pesan.index')); ?>">
                <i class="fas fa-fw fa-envelope"></i>
                <span>Pesan</span>
                <?php
                    $jml = DB::table('pesan')
                        ->where('is_read', '=', 0)
                        ->count();
                ?>
                <?php if($jml > 0): ?>
                    <span class="badge bg-danger-soft text-danger ms-auto">1 New</span>
                <?php endif; ?>
            </a>

        </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['user_show', 'role_show', 'toko_show'])): ?>
        <li class="nav-item <?php echo e(set_active(['roles*', 'user*', 'setting-toko*'])); ?>">
            <a class="nav-link <?php echo e(request()->routeIs('roles*', 'user*', 'setting-toko*') ? '' : 'collapsed'); ?>" href="#"
                data-toggle="collapse" data-target="#collapsePages3" aria-expanded="true" aria-controls="collapsePages3">
                <i class="fas fa-fw fa-cogs"></i>
                <span>Setting</span>
            </a>
            <div id="collapsePages3"
                class="collapse <?php echo e(request()->routeIs('roles*', 'user*', 'setting-toko*') ? 'show' : ''); ?>"
                aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_show')): ?>
                        <a class="collapse-item <?php echo e(set_active(['user*'])); ?>" href="<?php echo e(route('user.index')); ?>"> User</a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_show')): ?>
                        <a class="collapse-item <?php echo e(set_active(['roles*'])); ?>" href="<?php echo e(route('roles.index')); ?>"> Roles</a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('toko_show')): ?>
                        <a class="collapse-item <?php echo e(set_active(['setting-toko*'])); ?>"
                            href="<?php echo e(route('setting-toko.index')); ?>"> Setting Toko</a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('belanja_show')): ?>
                        <a class="collapse-item <?php echo e(set_active(['cara-belanja*'])); ?>"
                            href="<?php echo e(route('cara-belanja.index')); ?>"> Cara Belanja</a>
                    <?php endif; ?>
                </div>
            </div>
        </li>
    <?php endif; ?>
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul>
<?php /**PATH /home/u1801231/public_html/ip-komputer.com/resources/views/layouts/_dashboard/sidebar.blade.php ENDPATH**/ ?>