<?php $__env->startSection('title', 'Sign In'); ?>
<?php $__env->startSection('content'); ?>
    <!-- ============================================== HEADER : END ============================================== -->
    <div class="breadcrumb">
        <div class="container">
            <div class="breadcrumb-inner">
                <ul class="list-inline list-unstyled">
                    <li><a href="home.html">Home</a></li>
                    <li class='active'>Register</li>
                </ul>
            </div><!-- /.breadcrumb-inner -->
        </div><!-- /.container -->
    </div><!-- /.breadcrumb -->

    <div class="body-content">
        <div class="container">
            <div class="sign-in-page">
                <div class="row">
                    <div class="col-md-6">
                        <center>
                            <img src="<?php echo e(asset('temp-front-end/assets/images/register.webp')); ?>" alt="" width="100%">
                        </center>

                    </div>
                    <div class="col-md-6 col-sm-6 create-new-account">
                        <h4 class="checkout-subtitle">
                            <div class="alert alert-info">
                                <i class="fa fa-info-circle" aria-hidden="true"></i> Create a new account
                            </div>
                        </h4>

                        <form class="register-form outer-top-xs" role="form" method="POST"
                            action="<?php echo e(route('register-user')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label class="info-title" for="email">Email<span>*</span></label>
                                <input style="box-shadow: 0 0 5pt 2pt #D3D3D3;
                                    outline-width: 0px;" type="email" name="email" autocomplete="off"
                                    value="<?php echo e(old('email')); ?>" class="form-control unicase-form-control text-input "
                                    id="email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: red;"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label class="info-title" for="nama">Nama Lengkap <span>*</span></label>
                                <input style="box-shadow: 0 0 5pt 2pt #D3D3D3;
                                    outline-width: 0px;" type="text" name="nama" autocomplete="off"
                                    value="<?php echo e(old('nama')); ?>" class="form-control unicase-form-control text-input"
                                    id="nama">
                                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: red;"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label class="info-title" for="telpon">Telpon <span>*</span></label>
                                <input style="box-shadow: 0 0 5pt 2pt #D3D3D3;
                                    outline-width: 0px;" type="text" name="telpon" autocomplete="off"
                                    value="<?php echo e(old('telpon')); ?>" class="form-control unicase-form-control text-input"
                                    id="telpon">
                                <?php $__errorArgs = ['telpon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: red;"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label class="info-title" for="password">Password <span>*</span></label>
                                <input style="box-shadow: 0 0 5pt 2pt #D3D3D3;
                                    outline-width: 0px;" type="password" name="password" autocomplete="off"
                                    class="form-control unicase-form-control text-input" id="password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: red;"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group row">
                                <label for="captcha" class="col-md-4 col-form-label text-md-right">Captcha</label>
                                <div class="col-md-6 captcha">
                                    <span><?php echo captcha_img(); ?></span>
                                    <button type="button" class="btn btn-danger" class="reload" id="reload">
                                    &#x21bb;
                                    </button>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="captcha" class="col-md-4 col-form-label text-md-right">Enter Captcha</label>
                                <div class="col-md-6">
                                    <input id="captcha" type="text" class="form-control" placeholder="Enter Captcha" name="captcha">
                                </div>
                                <?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: red;"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <button type="submit" class="btn-upper btn btn-primary checkout-page-button">Sign Up</button>
                        </form>


                    </div>
                    <!-- create a new account -->
                </div><!-- /.row -->
            </div><!-- /.sigin-in-->
        </div><!-- /.container -->
    </div><!-- /.body-content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">
    $('#reload').click(function () {
        $.ajax({
            type: 'GET',
            url: '<?php echo e(route('reloadCaptcha')); ?>',
            success: function (data) {
                // console.log(data)
                $(".captcha span").html(data.captcha);
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1801231/public_html/ip-komputer.com/resources/views/frontend/register.blade.php ENDPATH**/ ?>