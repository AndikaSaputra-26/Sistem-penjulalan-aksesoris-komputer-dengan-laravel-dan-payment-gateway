<td>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('photo_view')): ?>
        <a href="#" class="btn btn-success btn-xs mb-1" data-toggle="modal"
        data-id="<?php echo e($model->id); ?>"
        id="view_gambar"
        data-nama="<?php echo e($model->nama); ?>"
        data-target="#largeModal" title="View Gambar"><i class="fas fa-eye"></i></a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('produk_update')): ?>
        <a href="<?php echo e(route('produk.edit', $model->id)); ?>" class="btn btn-primary btn-xs mb-1" title="Edit">
            <i class="fas fa-edit"></i>
        </a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('produk_delete')): ?>
        <form action="<?php echo e(route('produk.destroy', $model->id)); ?>" method="post" class="d-inline"
            onsubmit="return confirm('Yakin ingin menghapus data ini?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button class="btn btn-danger btn-xs mb-1" title="Hapus">
                <i class="fas fa-trash-alt"></i>
            </button>
        </form>
    <?php endif; ?>
</td>
<?php /**PATH /home/u1801231/public_html/ip-komputer.com/resources/views/produk/_action.blade.php ENDPATH**/ ?>