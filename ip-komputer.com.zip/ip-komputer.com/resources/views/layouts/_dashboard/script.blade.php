<script src="{{ asset('temp/vendor/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('temp/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('temp/vendor/jquery-easing/jquery.easing.min.js') }}"></script>
<script src="{{ asset('temp/js/sb-admin-2.min.js') }}"></script>
<script src="{{ asset('temp/vendor/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('temp/vendor/datatables/dataTables.bootstrap4.min.js') }}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/highcharts/6.0.6/highcharts.js" charset="utf-8"></script>

{{-- @if (count($errors) > 0)
<script type="text/javascript">
    $( document ).ready(function() {
         $('#edit-profile').modal('show');
    });
</script> --}}
{{-- @endif --}}

