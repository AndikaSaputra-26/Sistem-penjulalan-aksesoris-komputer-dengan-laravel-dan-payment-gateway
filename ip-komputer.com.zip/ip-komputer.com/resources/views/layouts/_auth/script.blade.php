<script src="{{ asset('temp/vendor/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('temp/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('temp/vendor/jquery-easing/jquery.easing.min.js') }}"></script>
<script src="{{ asset('temp/js/sb-admin-2.min.js') }}"></script>
