@extends('layouts.master')
@section('title', 'Laporan Transaksi')
@section('content')
    <div class="container-fluid">
        {{ Breadcrumbs::render('laporan-penjualan') }}
        <div class="row">
            <div class="col-md-12">
                <div class="card shadow mb-4">
                    <div class="card-body">

                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
